package cts.dumitrache.ioana.g1080.pattern.state;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cerere cerere= new Cerere();
		cerere.confirmare();
		cerere.verificare();
		cerere.avizareDecanat();
		cerere.respingere();
		
	}

}
