package cts.dumitrache.ioana.g1080.pattern.state;
public interface ICerereStudent {
    public void confirmare();

    public void verificare();

    public void avizareDecanat();

    public void respingere();
}