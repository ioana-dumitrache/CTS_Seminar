package cts.dumitrache.ioana.g1080.pattern.state;

public class Respinsa implements ICerereStudent {

	@Override
	public void confirmare() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void verificare() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void avizareDecanat() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void respingere() {
		// TODO Auto-generated method stub
		
	}

}
